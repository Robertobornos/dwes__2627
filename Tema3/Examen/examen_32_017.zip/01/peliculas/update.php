<?php
require_once 'libs/functions.php';

$peliculas = get_peliculas();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0);

    
    $generos = array_values(array_filter(array_map('trim', explode(',', $_POST['generos'] ?? ''))));

    foreach ($peliculas as $i => $p) {
        if ($p['id'] === $id) {
            $peliculas[$i] = [
                'id'        => $id,
                'titulo'    => trim($_POST['titulo'] ?? ''),
                'idioma'    => trim($_POST['idioma'] ?? ''),
                'director'  => trim($_POST['director'] ?? ''),
                'generos'   => $generos,
                'año'       => (int)($_POST['anio'] ?? 0),
                'duracion'  => (int)($_POST['duracion'] ?? 0),
                'recaudado' => (float)($_POST['recaudado'] ?? 0),
            ];
        }
    }
}

require 'views/index.view.php';